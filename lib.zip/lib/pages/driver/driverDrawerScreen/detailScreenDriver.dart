import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lottie/lottie.dart';
import '../../../SharedPreference/AppSession.dart';
import '../../../models/deliveryDetail.dart';
import '../../../services/auth_service.dart';
import '../../../constant.dart';
import '../tripScreens/completeTrip.dart';

class DetailsFormDriverScreen extends StatefulWidget {
  final fromScreen;
  final orderId;
  const DetailsFormDriverScreen({super.key, this.fromScreen, this.orderId});

  @override
  State<DetailsFormDriverScreen> createState() =>
      _DetailsFormDriverScreenState();
}

class _DetailsFormDriverScreenState extends State<DetailsFormDriverScreen> {
  // controllers (filled from API)
  final TextEditingController pickupController = TextEditingController();
  final TextEditingController dropController = TextEditingController();
  final TextEditingController storeNameController = TextEditingController();
  final TextEditingController sellerNameController = TextEditingController();
  final TextEditingController sellerNumberController = TextEditingController();
  final TextEditingController purchaserNameController = TextEditingController();
  final TextEditingController purchaserNumberController =
  TextEditingController();
  final TextEditingController unit1Controller = TextEditingController();
  final TextEditingController stairs1Controller = TextEditingController();
  final TextEditingController unit2Controller = TextEditingController();
  final TextEditingController stairs2Controller = TextEditingController();

  bool byMe = true;
  bool bySomeoneElse = false;

  bool stair1 = false;
  bool elevator1 = true;

  bool stair2 = false;
  bool elevator2 = true;

  // Delivery detail model
  Deliverydata? deliveryData;

  // Price strings
  String driverPrice = "";
  String adminPrice = "";
  String totalPrice = "";

  // package count / items
  int packageCount = 0;

  // booking type inferred from API (maps to your UI buckets)
  String bookingTypeForUI = "";

  // loader
  bool loading = true;

  Color border = Colors.grey.shade300;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _fetchDeliveryDetail(); // safe call AFTER widget build
    });
  }

  void _showLoader() {
    showDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black.withOpacity(0.4), // <<< adds black dim background
      builder: (_) => Center(
        child: Lottie.asset(
          'assets/animation/dots_loader.json',
          repeat: true,
          fit: BoxFit.contain,
        ),
      ),
    );
  }

  Future<void> _fetchDeliveryDetail() async {
    _showLoader(); // <<< show loader

    try {
      final resp = await AuthService.deliveryDetail(
        delivery_id: widget.orderId.toString(),
      );

      final model = DeliverydetailModel.fromJson(resp);

      if (model.result == "success" && model.deliverydata != null) {
        final d = model.deliverydata!;
        deliveryData = d;

        // fill your controllers
        pickupController.text = d.pickupaddress ?? "";
        dropController.text = d.dropoffaddress ?? "";

        bookingTypeForUI = (d.bookingType ?? "").toLowerCase();
        if (bookingTypeForUI == "onlinemarket") bookingTypeForUI = "online";
        else if (bookingTypeForUI == "retailstore") bookingTypeForUI = "retail";
        else if (bookingTypeForUI == "furnituredelivery") bookingTypeForUI = "furniture";
        else if (bookingTypeForUI == "movinghelp") bookingTypeForUI = "moving";
        else if (bookingTypeForUI == "courierservice") bookingTypeForUI = "courier";

        storeNameController.text = d.storeName ?? "";
        sellerNameController.text = d.sellerName ?? "";
        sellerNumberController.text = d.sellerNumber ?? "";
        purchaserNameController.text = d.purchaserName ?? "";
        purchaserNumberController.text = d.purchaserNumber ?? "";

        unit1Controller.text = d.unitOrApartment ?? "";
        unit2Controller.text = d.unitOrApartment2 ?? "";

        stairs1Controller.text = d.numberOfStairs ?? "";
        stairs2Controller.text = d.numberOfStairs2 ?? "";

        stair1 = (d.staircase == "1" || d.staircase == "true");
        elevator1 = (d.elevators == "1" || d.elevators == "true");
        stair2 = (d.staircase2 == "1" || d.staircase2 == "true");
        elevator2 = (d.elevator2 == "1" || d.elevator2 == "true");

        byMe = (d.itemPurchaseBy == "1");
        bySomeoneElse = !byMe;

        driverPrice = d.driverCost ?? "";
        adminPrice = d.adminCost ?? "";

        if (d.driverCost != null &&
            d.adminCost != null &&
            d.driverCost!.isNotEmpty &&
            d.adminCost!.isNotEmpty) {
          try {
            final drv = double.parse(d.driverCost!);
            final adm = double.parse(d.adminCost!);
            totalPrice = (drv + adm).toStringAsFixed(2);
          } catch (_) {
            totalPrice = d.deliveryCost ?? "";
          }
        } else {
          totalPrice = d.deliveryCost ?? "";
        }

        packageCount = d.package?.length ?? 0;
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(model.message ?? "Failed to fetch details")),
        );
      }
    } catch (e) {
      print("❌ deliveryDetail error: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error fetching delivery details")),
      );
    } finally {
      _hideLoader(); // <<< hide loader
      setState(() {}); // refresh UI
    }
  }

  void _hideLoader() {
    Navigator.of(context, rootNavigator: true).pop();
  }

  Future<void> _acceptDelivery() async {
    try {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (_) => const Center(child: CircularProgressIndicator()),
      );

      final res = await AuthService.acceptDeliveryRequest(
        driver_id: AppSession().userId,
        order_id: widget.orderId.toString(),
      );

      Navigator.pop(context); // remove loader

      if (res["result"] == "success") {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Delivery Accepted")),
        );
        // return to previous screen and signal accepted
        Navigator.pop(context, {'accepted': true, 'order_id': widget.orderId});
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(res["message"] ?? "Failed to accept")),
        );
      }
    } catch (e) {
      Navigator.pop(context);
      print("❌ accept error: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error: $e")),
      );
    }
  }

  Future<void> _declineDelivery() async {
    try {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (_) => const Center(child: CircularProgressIndicator()),
      );

      final res = await AuthService.decline_order_driver(
        driver_id: AppSession().userId,
        order_id: widget.orderId.toString(),
      );

      Navigator.pop(context); // remove loader

      if (res["result"] == "success") {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Delivery Declined")),
        );
        Navigator.pop(context, {'declined': true, 'order_id': widget.orderId});
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(res["message"] ?? "Failed to decline")),
        );
      }
    } catch (e) {
      Navigator.pop(context);
      print("❌ decline error: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error: $e")),
      );
    }
  }

  void showConfirmPopup(BuildContext context, String status) {
    showDialog(
      context: context,
      barrierDismissible: false, // user must choose Cancel or Okay
      builder: (context) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
          ),
          backgroundColor: Colors.white,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 22),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // TITLE
                Text(
                  status == "start" ? "Start Delivery" : "Accept Delivery",
                  style: GoogleFonts.poppins(
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                    color: Colors.black,
                  ),
                ),
                const SizedBox(height: 8),

                // MESSAGE
                Text(
                  status == "start"
                      ? "Do you want to Start delivery?"
                      : "Do you want to accept delivery?",
                  style: GoogleFonts.poppins(
                    fontSize: 14,
                    color: Colors.black87,
                  ),
                ),
                const SizedBox(height: 24),

                // BUTTONS ROW
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    // CANCEL
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Text(
                        "No",
                        style: GoogleFonts.poppins(
                          fontSize: 15,
                          color: Colors.redAccent,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),

                    const SizedBox(width: 24),

                    // OKAY
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColor.primaryColor,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                        padding: const EdgeInsets.symmetric(
                          horizontal: 20,
                          vertical: 10,
                        ),
                      ),
                      onPressed: () async {
                        Navigator.pop(context);
                        if (status == "start") {
                          Helper.moveToScreenwithPush(
                              context, CompleteTripScreen());
                        } else {
                          // Accept flow — call API
                          await _acceptDelivery();
                        }
                      },
                      child: Text(
                        "Yes",
                        style: GoogleFonts.poppins(
                          fontSize: 15,
                          color: AppColor.secondaryColor, // white
                        ),
                      ),
                    ),
                  ],
                )
              ],
            ),
          ),
        );
      },
    );
  }

  // ----------------- NEW: Read-only box (same styling as your boxField) -----------------
  Widget readOnlyBox(String text) {
    return Container(
      height: 50,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 5,
            offset: const Offset(1, 3),
          )
        ],
      ),
      alignment: Alignment.centerLeft,
      padding: const EdgeInsets.symmetric(horizontal: 15),
      child: Text(
        text.isNotEmpty ? text : "-",
        style: GoogleFonts.poppins(
          color: AppColor.primaryColor,
          fontSize: 15,
        ),
      ),
    );
  }

  Widget locationTile(String title, String address) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title,
            style:
            GoogleFonts.poppins(fontSize: 13, fontWeight: FontWeight.w700)),
        const SizedBox(height: 4),
        Text(address, style: GoogleFonts.poppins(fontSize: 12.5, height: 1.3)),
      ],
    );
  }

  Widget toggleTile(String title, bool value, VoidCallback tap) {
    return Row(
      children: [
        GestureDetector(
          onTap: () {}, // read-only - no toggle
          child: Container(
            width: 22,
            height: 22,
            decoration: BoxDecoration(
              border: Border.all(color: border),
              borderRadius: BorderRadius.circular(6),
              color: value ? AppColor.secondprimaryColor : Colors.white,
            ),
            child: value
                ? Icon(Icons.check, size: 16, color: AppColor.secondaryColor)
                : null,
          ),
        ),
        const SizedBox(width: 10),
        Text(title, style: GoogleFonts.poppins(fontSize: 14)),
      ],
    );
  }

  Widget checkboxReadOnly(bool v) {
    return Container(
      width: 22,
      height: 22,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: AppColor.borderColor),
        color: v ? AppColor.secondprimaryColor : Colors.white,
      ),
      child: v
          ? Icon(Icons.check, size: 16, color: AppColor.secondaryColor)
          : const SizedBox(),
    );
  }

  Widget priceText(String text) => Text(
    text,
    style: GoogleFonts.poppins(
        fontSize: 16, fontWeight: FontWeight.w600, color: AppColor.primaryColor),
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,

      // APPBAR
      appBar: AppBar(
        backgroundColor: AppColor.secondaryColor,
        centerTitle: true,
        leading: GestureDetector(
          onTap: () => Navigator.pop(context),
          child: const Icon(Icons.arrow_back_ios, size: 18, color: Colors.black),
        ),
        title: Text(
          "Details",
          style: GoogleFonts.poppins(
              fontSize: 17, fontWeight: FontWeight.w600, color: AppColor.primaryColor),
        ),
        actions: [
          SvgPicture.asset("assets/images/track.svg", height: 40, width: 90),
        ],
      ),

      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // PICKUP / DROP CARD
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xffF8FAFD),
                borderRadius: BorderRadius.circular(16),
                boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 8, offset: const Offset(0,3))],
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Image.asset("assets/images/pickupDropup.png", height: 120, width: 22, fit: BoxFit.contain),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        locationTile("Pickup", pickupController.text),
                        const Divider(),
                        locationTile("Drop-Off", dropController.text),
                      ],
                    ),
                  )
                ],
              ),
            ),

            // const SizedBox(height: 18),
            // sectionTitle("Send By"),
            // const SizedBox(height: 10),
            //
            // Row(
            //   children: [
            //     checkboxReadOnly(byMe),
            //     const SizedBox(width: 8),
            //     label("By Me"),
            //     const SizedBox(width: 22),
            //     checkboxReadOnly(bySomeoneElse),
            //     const SizedBox(width: 8),
            //     label("Someone Else"),
            //   ],
            // ),

            const SizedBox(height: 20),

            // ---------------- TOP FIELDS (Retail / Online / Courier) ----------------
            _buildTopFieldsForBookingType(),

            const SizedBox(height: 18),

            // ---------------- Sender block (always shown per option B) ----------------
            senderReceiverBlock(
              name: purchaserNameController.text.isNotEmpty ? purchaserNameController.text : (deliveryData?.userName ?? ""),
              phone: purchaserNumberController.text.isNotEmpty ? purchaserNumberController.text : (deliveryData?.userPhone ?? ""),
              apartment: unit1Controller.text.isNotEmpty ? unit1Controller.text : (deliveryData?.unitOrApartment ?? ""),
              stair: stair1,
              elevator: elevator1,
              onStairTap: () {},
              onElevatorTap: () {},
              showStairsElevator: _shouldShowStairsElevator(),
            ),

            const SizedBox(height: 10),

            // ---------------- Receiver block (always shown per option B) ----------------
            senderReceiverBlock(
              name: purchaserNameController.text.isNotEmpty ? purchaserNameController.text : (deliveryData?.purchaserName ?? ""),
              phone: purchaserNumberController.text.isNotEmpty ? purchaserNumberController.text : (deliveryData?.purchaserNumber ?? ""),
              apartment: unit2Controller.text.isNotEmpty ? unit2Controller.text : (deliveryData?.unitOrApartment2 ?? ""),
              stair: stair2,
              elevator: elevator2,
              onStairTap: () {},
              onElevatorTap: () {},
              showStairsElevator: _shouldShowStairsElevator(),
            ),

            const SizedBox(height: 18),
            sectionTitle("Total Items"),
            const SizedBox(height: 5),

            // Show package count or individual package info
            readOnlyBox(packageCount > 0 ? "${packageCount} Package${packageCount>1?'s':''}" : "No packages"),

          ],
        ),
      ),

      bottomNavigationBar: Container(
        padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 16),
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 8, offset: const Offset(0, -2))],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            priceText("Driver Price: ₹${driverPrice.isNotEmpty ? driverPrice : "0.00"}"),
            priceText("Admin Price: ₹${adminPrice.isNotEmpty ? adminPrice : (deliveryData?.adminCost ?? "")}"),
            const SizedBox(height: 4),
            const Divider(),
            Text(
              "Total Price: ₹${totalPrice.isNotEmpty ? totalPrice : (deliveryData?.deliveryCost ?? "")}",
              style: GoogleFonts.poppins(fontSize: 20, fontWeight: FontWeight.w700, color: AppColor.secondprimaryColor),
            ),
            const SizedBox(height: 14),

            widget.fromScreen == "trip"
                ? Row(
              children: [
                Expanded(
                  child: InkWell(
                    onTap: () {
                      showConfirmPopup(context, "start");
                    },
                    child: Container(
                      height: 42,
                      decoration: BoxDecoration(color: Colors.black, borderRadius: BorderRadius.circular(10)),
                      child: Center(child: Text("Start Trips", style: GoogleFonts.poppins(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w500))),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Container(
                    height: 42,
                    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10), border: Border.all(color: Colors.red, width: 1.3)),
                    child: Center(child: Text("Report", style: GoogleFonts.poppins(color: Colors.red, fontSize: 14, fontWeight: FontWeight.w500))),
                  ),
                ),
              ],
            )
                : Row(
              children: [
                Expanded(
                  child: InkWell(
                    onTap: () {
                      showConfirmPopup(context, "accept");
                    },
                    child: Container(
                      height: 42,
                      decoration: BoxDecoration(color: Colors.black, borderRadius: BorderRadius.circular(10)),
                      child: Center(child: Text("Accept", style: GoogleFonts.poppins(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w500))),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: InkWell(
                    onTap: () async {
                      // confirmation then call decline
                      final confirm = await showDialog<bool>(
                        context: context,
                        builder: (_) => AlertDialog(
                          title: const Text("Decline Delivery"),
                          content: const Text("Do you want to decline this delivery?"),
                          actions: [
                            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text("No")),
                            TextButton(onPressed: () => Navigator.pop(context, true), child: const Text("Yes")),
                          ],
                        ),
                      );
                      if (confirm == true) {
                        await _declineDelivery();
                      }
                    },
                    child: Container(
                      height: 42,
                      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10), border: Border.all(color: Colors.red, width: 1.3)),
                      child: Center(child: Text("Decline", style: GoogleFonts.poppins(color: Colors.red, fontSize: 14, fontWeight: FontWeight.w500))),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ---------------- TOP FIELDS -> per booking type (Retail / Online / Courier) ----------------
  Widget _buildTopFieldsForBookingType() {
    // Retail: store name + purchased by + purchaser name/number
    if (bookingTypeForUI == "retail") {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          label("Store Name"),
          const SizedBox(height: 5),
          readOnlyBox(storeNameController.text),
          const SizedBox(height: 16),

          label("Item Purchased By"),
          const SizedBox(height: 6),
          Row(
            children: [
              checkboxReadOnly(byMe),
              const SizedBox(width: 8),
              label("By Me"),
              const SizedBox(width: 22),
              checkboxReadOnly(bySomeoneElse),
              const SizedBox(width: 8),
              label("Someone Else"),
            ],
          ),
          const SizedBox(height: 16),

          label("Purchaser Name"),
          const SizedBox(height: 5),
          readOnlyBox(purchaserNameController.text),
          const SizedBox(height: 16),

          label("Purchaser Number"),
          const SizedBox(height: 5),
          readOnlyBox(purchaserNumberController.text),
        ],
      );
    }

    // Online: seller name/number + purchased by + purchaser fields
    if (bookingTypeForUI == "online") {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          label("Seller Name"),
          const SizedBox(height: 5),
          readOnlyBox(sellerNameController.text),
          const SizedBox(height: 16),

          label("Seller Number"),
          const SizedBox(height: 5),
          readOnlyBox(sellerNumberController.text),
          const SizedBox(height: 16),

          label("Item Purchased By"),
          const SizedBox(height: 6),
          Row(
            children: [
              checkboxReadOnly(byMe),
              const SizedBox(width: 8),
              label("By Me"),
              const SizedBox(width: 22),
              checkboxReadOnly(bySomeoneElse),
              const SizedBox(width: 8),
              label("Someone Else"),
            ],
          ),
          const SizedBox(height: 16),

          label("Purchaser Name"),
          const SizedBox(height: 5),
          readOnlyBox(purchaserNameController.text),
          const SizedBox(height: 16),

          label("Purchaser Number"),
          const SizedBox(height: 5),
          readOnlyBox(purchaserNumberController.text),
        ],
      );
    }

    // Courier: sender details (top)
    if (bookingTypeForUI == "courier") {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          label("Sender Name"),
          const SizedBox(height: 5),
          readOnlyBox(storeNameController.text.isNotEmpty ? storeNameController.text : (deliveryData?.sellerName ?? "")),
          const SizedBox(height: 16),
          label("Sender Number"),
          const SizedBox(height: 5),
          readOnlyBox(sellerNumberController.text.isNotEmpty ? sellerNumberController.text : (deliveryData?.sellerNumber ?? "")),
        ],
      );
    }

    // Furniture / Moving: top fields could be blank — we show unit blocks below (senderReceiver blocks)
    return const SizedBox();
  }

  // Decide if stairs/elevator should be visible inside senderReceiverBlock
  bool _shouldShowStairsElevator() {
    // According to rules:
    // - retail: HIDE stairs/elevator
    // - online: SHOW stairs/elevator
    // - courier: SHOW
    // - furniture: SHOW
    // - moving: SHOW
    if (bookingTypeForUI == "retail") return false;
    return (bookingTypeForUI == "online" ||
        bookingTypeForUI == "courier" ||
        bookingTypeForUI == "furniture" ||
        bookingTypeForUI == "moving");
  }

  Widget senderReceiverBlock({
    required String name,
    required String phone,
    required String apartment,
    required bool stair,
    required bool elevator,
    required VoidCallback onStairTap,
    required VoidCallback onElevatorTap,
    bool showStairsElevator = true,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // inputLabel("Name"),
        // const SizedBox(height: 6),
        // readOnlyBox(name),
        // const SizedBox(height: 14),
        // inputLabel("Phone Number"),
        // const SizedBox(height: 6),
        // readOnlyBox(phone),
        const SizedBox(height: 14),
        inputLabel("Unit or Apartment"),
        const SizedBox(height: 6),
        readOnlyBox(apartment),
        const SizedBox(height: 14),
        if (showStairsElevator) ...[
          toggleTile("Have to Use Staircase", stair, onStairTap),
          const SizedBox(height: 14),
          inputLabel("Number of Stairs"),
          const SizedBox(height: 6),
          readOnlyBox(stair ? (stairs1Controller.text.isNotEmpty ? stairs1Controller.text : (deliveryData?.numberOfStairs ?? "")) : (stairs2Controller.text.isNotEmpty ? stairs2Controller.text : (deliveryData?.numberOfStairs2 ?? ""))),
          const SizedBox(height: 14),
          toggleTile("Can Use Elevators", elevator, onElevatorTap),
        ],
      ],
    );
  }

  Widget sectionTitle(String text) => Text(
    text,
    style: GoogleFonts.poppins(fontSize: 15, fontWeight: FontWeight.w600),
  );

  Widget inputLabel(String text) => Text(
    text,
    style: GoogleFonts.poppins(
        fontSize: 14, fontWeight: FontWeight.w500, color: Colors.black87),
  );

  Widget label(String text) => Text(
    text,
    style: GoogleFonts.poppins(
        fontSize: 15, fontWeight: FontWeight.w500, color: AppColor.primaryColor),
  );
}
