class SettingsModel {
  final String result;
  final String message;
  final Vehicle vehicle;

  SettingsModel({required this.result, required this.message, required this.vehicle});

  factory SettingsModel.fromJson(Map<String, dynamic> json) {
    return SettingsModel(
      result: json['result'] ?? '',
      message: json['message'] ?? '',
      vehicle: Vehicle.fromJson(json['vehicle'] ?? {}),
    );
  }
}

class Vehicle {
  final double cargoVan;
  final double pickupTruck;
  final double car;
  final double miniVan;
  final double boxTruck;
  final double stairs;
  final double driverAside;
  final double retailStoreBasePrice;
  final double onlineMarketBasePrice;
  final double furnitureDeliveryBasePrice;
  final double movingHelpBasePrice;
  final double courierServiceBasePrice;
  final double perMileCharge;
  final double adminPercentage;

  Vehicle({
    required this.cargoVan,
    required this.pickupTruck,
    required this.car,
    required this.miniVan,
    required this.boxTruck,
    required this.stairs,
    required this.driverAside,
    required this.retailStoreBasePrice,
    required this.onlineMarketBasePrice,
    required this.furnitureDeliveryBasePrice,
    required this.movingHelpBasePrice,
    required this.courierServiceBasePrice,
    required this.perMileCharge,
    required this.adminPercentage,
  });

  factory Vehicle.fromJson(Map<String, dynamic> json) {
    double parseDouble(dynamic value) {
      if (value == null) return 0.0;
      if (value is double) return value;
      if (value is int) return value.toDouble();
      if (value is String) {
        // remove non-numeric chars just in case
        return double.tryParse(value.replaceAll(RegExp(r'[^\d.-]'), '')) ?? 0.0;
      }
      return 0.0;
    }

    return Vehicle(
      cargoVan: parseDouble(json['cargo_van']),
      pickupTruck: parseDouble(json['pickup_truck']),
      car: parseDouble(json['car']),
      miniVan: parseDouble(json['mini_van']),
      boxTruck: parseDouble(json['box_truck']),
      stairs: parseDouble(json['stairs']),
      driverAside: parseDouble(json['driver_aside']),
      retailStoreBasePrice: parseDouble(json['retail_store_base_price']),
      onlineMarketBasePrice: parseDouble(json['online_market_base_price']),
      furnitureDeliveryBasePrice: parseDouble(json['furniture_delivery_base_price']),
      movingHelpBasePrice: parseDouble(json['moving_help_base_price']),
      courierServiceBasePrice: parseDouble(json['courier_service_base_price']),
      perMileCharge: parseDouble(json['per_mile_charge']),
      adminPercentage: parseDouble(json['admin_percentage']),
    );
  }
}