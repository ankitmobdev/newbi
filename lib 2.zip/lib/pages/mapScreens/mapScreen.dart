import 'package:flutter/material.dart';
import 'package:flutter_google_places_hoc081098/flutter_google_places_hoc081098.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_api_headers/google_api_headers.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:google_maps_webservice/places.dart';
import 'package:permission_handler/permission_handler.dart';
import 'dart:io' show Platform;
import '../../constant.dart';   // <-- AppColor (secondaryColor, textColor)

typedef CallBackFunction = void Function(
    String location, double latitude, double longitude);

class LocationWidget extends StatefulWidget {
  final CallBackFunction callback;

  LocationWidget({required this.callback});

  @override
  State<LocationWidget> createState() => LocationWidgetUI();
}

class LocationService {
  Future<bool> _requestLocationPermission() async {
    if (!await Geolocator.isLocationServiceEnabled()) {
      await Geolocator.openLocationSettings();
      return false;
    }
    PermissionStatus permissionStatus = await Permission.location.request();

    if (permissionStatus == PermissionStatus.granted) return true;

    if (permissionStatus == PermissionStatus.permanentlyDenied) {
      await openAppSettings();
    }
    return false;
  }

  Future<Position?> getCurrentLocations(BuildContext context) async {
    if (Platform.isAndroid) {
      bool permissionGranted = await _requestLocationPermission();
      if (!permissionGranted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Location permission required")),
        );
        return null;
      }
    }

    try {
      return await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );
    } catch (e) {
      print('Error getting location: $e');
      return null;
    }
  }
}

class LocationWidgetUI extends State<LocationWidget> {
  final String googleApikey = "AIzaSyCRMjSEuYwTni9VcanTdHCptPfmly0htCc";

  GoogleMapController? mapController;
  LatLng startLocation = const LatLng(22.717807, 75.8780294);

  String location = "Search Location";
  double? latitude;
  double? longitude;

  bool _isMapReady = false;

  @override
  void initState() {
    super.initState();
    if (Platform.isIOS) {
      getCurrentLocation();
    } else {
      getAndroidLocation(context);
    }
  }

  void getAndroidLocation(BuildContext context) async {
    try {
      final position = await LocationService().getCurrentLocations(context);

      if (position != null) {
        List<Placemark> placemarks = await placemarkFromCoordinates(
          position.latitude,
          position.longitude,
        );

        setState(() {
          startLocation = LatLng(position.latitude, position.longitude);

          location =
          "${placemarks.first.street}, ${placemarks.first.subLocality}, ${placemarks.first.locality}, ${placemarks.first.administrativeArea}";
          _isMapReady = true;
        });
      }
    } catch (e) {
      print("error: $e");
    }
  }

  void getCurrentLocation() async {
    try {
      final position = await Geolocator.getCurrentPosition();
      List<Placemark> placemarks =
      await placemarkFromCoordinates(position.latitude, position.longitude);

      setState(() {
        startLocation = LatLng(position.latitude, position.longitude);

        location =
        "${placemarks.first.street}, ${placemarks.first.subLocality}, ${placemarks.first.locality}, ${placemarks.first.administrativeArea}";
        _isMapReady = true;
      });
    } catch (e) {
      print("error: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.secondaryColor,

      // ******************  APP BAR  ******************
      appBar: AppBar(
        backgroundColor: AppColor.secondaryColor,
        elevation: 0,
        centerTitle: true,
        leading: GestureDetector(
          onTap: () => Navigator.pop(context),
          child: const Icon(Icons.arrow_back_ios, color: Colors.black, size: 20),
        ),
        title: Text(
          "Select Location",
          style: GoogleFonts.poppins(
            fontSize: 18,
            fontWeight: FontWeight.w600,
            color: Colors.black,
          ),
        ),
      ),

      body: _isMapReady
          ? Stack(
        children: [
          GoogleMap(
            initialCameraPosition: CameraPosition(
              target: startLocation,
              zoom: 14,
            ),
            zoomGesturesEnabled: true,
            mapType: MapType.normal,
            onMapCreated: (controller) => mapController = controller,
            onCameraMove: (CameraPosition position) async {
              LatLng t = position.target;
              List<Placemark> p =
              await placemarkFromCoordinates(t.latitude, t.longitude);

              setState(() {
                location =
                "${p.first.street}, ${p.first.subLocality}, ${p.first.locality}, ${p.first.administrativeArea}";
                latitude = t.latitude;
                longitude = t.longitude;
              });
            },
          ),

          // ************ SEARCH BAR (CARD) ************
          Positioned(
            top: 16,
            left: 16,
            right: 16,
            child: GestureDetector(
              onTap: () async {
                var place = await PlacesAutocomplete.show(
                  context: context,
                  apiKey: googleApikey,
                  mode: Mode.overlay,
                  types: [],
                );

                if (place != null) {
                  setState(() => location = place.description!);

                  final plist = GoogleMapsPlaces(
                    apiKey: googleApikey,
                    apiHeaders: await GoogleApiHeaders().getHeaders(),
                  );

                  final detail =
                  await plist.getDetailsByPlaceId(place.placeId!);
                  final lat = detail.result.geometry!.location.lat;
                  final lng = detail.result.geometry!.location.lng;

                  mapController?.animateCamera(
                    CameraUpdate.newCameraPosition(
                      CameraPosition(target: LatLng(lat, lng), zoom: 17),
                    ),
                  );
                }
              },
              child: Container(
                padding:
                const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: Colors.black12),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.search, color: Colors.black54),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        location,
                        style: GoogleFonts.poppins(
                          fontSize: 15,
                          color: Colors.black87,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          // ************* MAP PIN ICON *************
           Center(
            child: Image.asset( "assets/images/mapIcon.png",),
          ),

          // ************* BOTTOM BUTTON *************
          Positioned(
            bottom: 24,
            left: 16,
            right: 16,
            child: SizedBox(
              height: 48,
              child: ElevatedButton(
                onPressed: () {
                  if (latitude != null && longitude != null) {
                    widget.callback(location, latitude!, longitude!);
                    Navigator.pop(context);
                  }
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.black,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                child: Text(
                  "Select Address",
                  style: GoogleFonts.poppins(
                    fontSize: 16,
                    color: Colors.white,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ),
          ),
        ],
      )
          : const Center(child: CircularProgressIndicator()),
    );
  }
}
