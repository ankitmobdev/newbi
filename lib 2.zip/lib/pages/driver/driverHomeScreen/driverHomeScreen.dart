import 'dart:io';

import 'package:flutter/material.dart';
import 'package:go_eat_e_commerce_app/constant.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:lottie/lottie.dart';

import '../../../SharedPreference/AppSession.dart';
import '../../../models/profilemodel.dart';
import '../../../services/auth_service.dart';
import '../driverDrawerScreen/availableDeliveries.dart';
import '../driverDrawerScreen/drawerScreenDriver.dart';

class DriverHomeScreen extends StatefulWidget {
  const DriverHomeScreen({super.key});

  @override
  State<DriverHomeScreen> createState() => _DriverHomeScreenState();
}

class _DriverHomeScreenState extends State<DriverHomeScreen> {
  GoogleMapController? mapController;
  ProfileModel? profileModel;
  LatLng driverLocation = const LatLng(22.717807, 75.8780294);
  bool isOnline = true;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      fetchProfile();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: const DriverCustomSideBar(),
      backgroundColor: AppColor.secondaryColor,

      // -------------------- APPBAR --------------------
      appBar: AppBar(
        backgroundColor:  AppColor.secondaryColor,
        elevation: 1,
        centerTitle: true,
        leading: Builder(
          builder: (context) => IconButton(
            icon: const Icon(Icons.menu, color: Colors.black),
            onPressed: () => Scaffold.of(context).openDrawer(),
          ),
        ),
        title: Text(
          "Home",
          style: GoogleFonts.poppins(
            color: Colors.black,
            fontSize: 18,
            fontWeight: FontWeight.w600,
          ),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: Center(child: customOnlineSwitch()),
          ),
        ],
      ),

      body: WillPopScope(
        onWillPop: () async {
          bool exitApp = await showDialog(
            context: context,
            builder: (_) => AlertDialog(
              title: Text("Exit App?"),
              content: Text("Do you really want to close the app?"),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context, false),
                  child: Text("No"),
                ),
                TextButton(
                  onPressed: () {
                    Navigator.pop(context, true);
                  },
                  child: Text("Yes"),
                ),
              ],
            ),
          );

          if (exitApp) {
            exit(0); // 🔥 Close the entire app
          }

          return false; // Prevent default back action
        },

        child: Stack(
          children: [
            GoogleMap(
              initialCameraPosition: CameraPosition(
                target: driverLocation,
                zoom: 14,
              ),
              mapType: MapType.normal,
              onMapCreated: (controller) => mapController = controller,
              zoomControlsEnabled: false,
              myLocationButtonEnabled: false,
            ),

            Center(
              child: Image.asset("assets/images/mapIcon.png"),
            ),

            Positioned(
              bottom: 20,
              left: 16,
              right: 16,
              child: ElevatedButton(
                onPressed: () {
                  Helper.moveToScreenwithPush(context, AvailableDeliveriesScreen());
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColor.primaryColor,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                child: Text(
                  "Nearby Deliveries",
                  style: GoogleFonts.poppins(
                    fontSize: 16,
                    color: AppColor.secondaryColor,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),

    );
  }

  Widget customOnlineSwitch() {
    return GestureDetector(
      onTap: () async {
        final newStatus = !isOnline;

        // TEMPORARILY show toggle moved
        setState(() => isOnline = newStatus);

        // API call
        await updateOnlineStatus(newStatus);
      },

      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        height: 22,
        width: 42,
        padding: const EdgeInsets.symmetric(horizontal: 2),
        decoration: BoxDecoration(
          color: isOnline ? Colors.green : Colors.grey.shade400,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Align(
          alignment: isOnline ? Alignment.centerRight : Alignment.centerLeft,
          child: Container(
            height: 17,
            width: 17,
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.white,
            ),
          ),
        ),
      ),
    );
  }

  // ================= GET PROFILE =================
  Future<void> fetchProfile() async {
    showLoader();

    try {
      final userId = AppSession().userId;
      final profile = await AuthService.getProfile(userId);

      profileModel = profile;

      isOnline= profile.data?.online_status == "1";
    } catch (e) {
      debugPrint("❌ Profile API Error: $e");
    }

    hideLoader();
    setState(() {});
  }

  Future<void> updateOnlineStatus(bool status) async {
    final userId = AppSession().userId;

    final typeValue = "online";
    final value = status ? "1" : "0";

    debugPrint("📤 Sending status → type: $typeValue, value: $value");

    showLoader();

    try {
      final res = await AuthService.preference(
        user_id: userId,
        type: typeValue,
        value: value,
      );

      hideLoader();

      debugPrint("📥 RESPONSE = $res");

      if (res["result"] == "success") {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("You are now ${status ? "Online" : "Offline"}"),
          ),
        );
      } else {
        // ❌ FAILED → REVERT SWITCH
        setState(() => isOnline = !status);

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(res["message"] ?? "Failed to update status"),
          ),
        );
      }
    } catch (e) {
      hideLoader();

      // ❌ ERROR → REVERT SWITCH
      setState(() => isOnline = !status);

      debugPrint("❌ Online status error: $e");

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("Something went wrong, please try again"),
        ),
      );
    }
  }


  // ================= LOADER =================
  void showLoader() {
    showDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black.withOpacity(0.4),
      builder: (_) => Center(
        child: Lottie.asset(
          'assets/animation/dots_loader.json',
          repeat: true,
        ),
      ),
    );
  }

  void hideLoader() {
    if (Navigator.canPop(context)) {
      Navigator.pop(context);
    }
  }
}
