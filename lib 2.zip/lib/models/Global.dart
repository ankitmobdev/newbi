import 'ItemDTO.dart';

class Global {
  static List<ItemDTO> packageList = [];
}